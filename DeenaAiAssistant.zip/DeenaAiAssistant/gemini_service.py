import json
import logging
import os

from google import genai
from google.genai import types


# Initialize Gemini client
client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))


def get_gemini_response(user_message):
    """
    Get AI response from Google Gemini API
    
    Args:
        user_message (str): The user's input message
        
    Returns:
        str: AI response message
    """
    try:
        # System prompt to define Deena's Assistant personality
        system_prompt = (
            "You are Deena's Assistant AI, a helpful, friendly, and knowledgeable AI assistant. "
            "You provide thoughtful, accurate, and engaging responses to users. "
            "Keep your responses conversational but informative. "
            "Be supportive and encouraging in your interactions."
        )
        
        # Create the full prompt with system context
        full_prompt = f"{system_prompt}\n\nUser: {user_message}\n\nDeena's Assistant:"
        
        # Call Gemini API with the newest model
        response = client.models.generate_content(
            model="gemini-2.0-flash-exp",
            contents=full_prompt
        )
        
        if response.text:
            return response.text.strip()
        else:
            return "I'm having trouble generating a response right now. Please try again."
            
    except Exception as e:
        logging.error(f"Error getting Gemini response: {str(e)}")
        return "I'm experiencing some technical difficulties with my AI service. Please try again shortly."