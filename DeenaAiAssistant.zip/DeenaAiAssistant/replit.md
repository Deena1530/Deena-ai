# Deena's Assistant AI - Replit Development Guide

## Overview

This is a Flask-based AI chatbot application called "Deena's Assistant AI" that provides an interactive web interface for users to chat with an AI assistant powered by OpenAI's GPT-4o model. The application features a modern, responsive chat interface with real-time messaging capabilities.

## System Architecture

**Frontend Architecture:**
- Static HTML/CSS/JavaScript frontend served by Flask
- Single-page application with dynamic message rendering
- Responsive design with gradient backgrounds and modern UI elements
- Real-time chat interface with loading indicators

**Backend Architecture:**
- Flask web framework with Python 3.11
- RESTful API design with JSON communication
- Modular structure separating concerns (routes, AI service, app configuration)
- CORS enabled for cross-origin requests

**Database Architecture:**
- PostgreSQL database for persistent data storage
- SQLAlchemy ORM for database operations
- Three main models: ChatSession, ChatMessage, UserFeedback
- Session-based conversation tracking with UUID identifiers
- Automatic table creation and schema management

**AI Integration:**
- Google Gemini 2.0 Flash Exp model integration (primary AI service)
- Hugging Face API integration as backup
- OpenAI GPT-4o model integration as tertiary option
- Intelligent fallback system with contextual responses
- System prompt defining "Deena's Assistant" personality
- Multi-tier error handling and response quality validation

## Key Components

**Core Files:**
- `main.py` - Application entry point and WSGI interface
- `app.py` - Flask application factory and configuration
- `routes.py` - HTTP route handlers and API endpoints
- `ai_service.py` - Multi-service AI integration with intelligent fallback
- `gemini_service.py` - Google Gemini AI integration
- `models.py` - Database models for chat sessions and messages

**Frontend Assets:**
- `templates/index.html` - Main chat interface template
- `static/style.css` - Styling with modern gradients and responsive design
- `static/script.js` - Client-side chat functionality and DOM manipulation

**Configuration:**
- `.replit` - Replit environment configuration with Python 3.11 and PostgreSQL
- `pyproject.toml` - Python dependencies and project metadata
- Environment-based configuration for API keys and secrets

## Data Flow

1. **User Input:** User types message in web interface
2. **Frontend Processing:** JavaScript captures input and sends POST request to `/ask` endpoint
3. **Backend Processing:** Flask route validates input and calls AI service
4. **AI Integration:** OpenAI API called with system prompt and user message
5. **Response Delivery:** AI response returned through JSON API to frontend
6. **UI Update:** JavaScript dynamically updates chat interface with new messages

## External Dependencies

**Core Dependencies:**
- `flask` (3.1.1+) - Web framework
- `openai` (1.91.0+) - OpenAI API client
- `gunicorn` (23.0.0+) - Production WSGI server
- `flask-cors` (6.0.1+) - Cross-origin resource sharing
- `flask-sqlalchemy` (3.1.1+) - Database ORM (configured but not actively used)

**Development Dependencies:**
- `psycopg2-binary` (2.9.10+) - PostgreSQL adapter
- `email-validator` (2.2.0+) - Email validation utilities

**External Services:**
- Google Gemini API - Primary AI service provider
- Hugging Face API - Backup AI service
- OpenAI API - Tertiary AI service option
- Requires `GEMINI_API_KEY` environment variable (primary)
- Optional: `HUGGINGFACE_API_KEY` and `OPENAI_API_KEY` for redundancy

## Deployment Strategy

**Production Deployment:**
- Gunicorn WSGI server binding to `0.0.0.0:5000`
- Autoscale deployment target configured in Replit
- Environment variable management for sensitive data
- Health check on port 5000

**Development Workflow:**
- Parallel workflow execution with automatic reloading
- Development server with debug mode enabled
- Hot reload capabilities for rapid development

**Infrastructure:**
- Nix package management for system dependencies
- PostgreSQL included but not currently utilized
- OpenSSL for secure connections

## Changelog

- June 26, 2025: Initial setup with Flask chatbot and OpenAI integration
- June 26, 2025: Added PostgreSQL database with chat session and message tracking
- June 26, 2025: Implemented conversation persistence and session management
- June 26, 2025: Integrated Google Gemini AI as primary service with intelligent fallback system
- June 26, 2025: Added contextual response patterns for API-free operation

## User Preferences

Preferred communication style: Simple, everyday language.