// DOM elements
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const messagesContainer = document.getElementById('messages');
const loadingIndicator = document.getElementById('loadingIndicator');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Focus on input field when page loads
    messageInput.focus();
    
    // Add event listeners
    messageInput.addEventListener('keypress', handleKeyPress);
    messageInput.addEventListener('input', handleInputChange);
    
    // Set initial timestamp for welcome message
    updateWelcomeMessageTime();
});

// Handle Enter key press to send message
function handleKeyPress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// Handle input changes to manage send button state
function handleInputChange() {
    const message = messageInput.value.trim();
    sendButton.disabled = !message;
}

// Update welcome message timestamp
function updateWelcomeMessageTime() {
    const welcomeMessage = document.querySelector('.welcome-message .message-time');
    if (welcomeMessage) {
        welcomeMessage.textContent = getCurrentTimeString();
    }
}

// Get current time as formatted string
function getCurrentTimeString() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Create message element
function createMessageElement(content, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = isUser ? 'user-message' : 'bot-message';
    
    const messageContent = document.createElement('div');
    messageContent.className = 'message-content';
    messageContent.innerHTML = isUser ? `<strong>You:</strong> ${escapeHtml(content)}` : `<strong>Deena's Assistant:</strong> ${escapeHtml(content)}`;
    
    const messageTime = document.createElement('div');
    messageTime.className = 'message-time';
    messageTime.textContent = getCurrentTimeString();
    
    messageDiv.appendChild(messageContent);
    messageDiv.appendChild(messageTime);
    
    return messageDiv;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Add message to chat
function addMessage(content, isUser = false) {
    const messageElement = createMessageElement(content, isUser);
    messagesContainer.appendChild(messageElement);
    scrollToBottom();
}

// Scroll to bottom of messages
function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Show/hide loading indicator
function setLoading(isLoading) {
    loadingIndicator.style.display = isLoading ? 'block' : 'none';
    sendButton.disabled = isLoading;
    messageInput.disabled = isLoading;
    
    if (isLoading) {
        sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    } else {
        sendButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
    }
}

// Send message function
async function sendMessage() {
    const message = messageInput.value.trim();
    
    // Validate message
    if (!message) {
        messageInput.focus();
        return;
    }
    
    // Add user message to chat
    addMessage(message, true);
    
    // Clear input and show loading
    messageInput.value = '';
    handleInputChange();
    setLoading(true);
    
    try {
        // Send request to server
        const response = await fetch('/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });
        
        // Handle response
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Check for error in response
        if (data.error) {
            throw new Error(data.error);
        }
        
        // Add AI response to chat
        addMessage(data.reply, false);
        
    } catch (error) {
        console.error('Error sending message:', error);
        
        // Show user-friendly error message
        let errorMessage = 'Sorry, I encountered an error while processing your message. ';
        
        if (error.message.includes('HTTP error')) {
            errorMessage += 'Please check your connection and try again.';
        } else if (error.message.includes('Failed to fetch')) {
            errorMessage += 'Unable to connect to the server. Please try again later.';
        } else {
            errorMessage += 'Please try again in a moment.';
        }
        
        addMessage(errorMessage, false);
    } finally {
        // Hide loading and re-enable input
        setLoading(false);
        messageInput.focus();
    }
}

// Handle connection errors and retries
let retryCount = 0;
const MAX_RETRIES = 3;

async function sendMessageWithRetry(message, attempt = 1) {
    try {
        const response = await fetch('/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        return await response.json();
        
    } catch (error) {
        if (attempt < MAX_RETRIES && (error.message.includes('Failed to fetch') || error.message.includes('HTTP 5'))) {
            // Wait before retry (exponential backoff)
            await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt - 1)));
            return sendMessageWithRetry(message, attempt + 1);
        }
        throw error;
    }
}

// Add visual feedback for successful message sending
function showMessageSentFeedback() {
    sendButton.style.background = '#28a745';
    setTimeout(() => {
        sendButton.style.background = '#007bff';
    }, 300);
}

// Handle page visibility changes to pause/resume functionality
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        messageInput.focus();
    }
});

// Prevent form submission if wrapped in form
document.addEventListener('submit', function(e) {
    e.preventDefault();
    sendMessage();
});
