import os
import logging
import requests
import json
from gemini_service import get_gemini_response

# API keys for different services
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
HUGGINGFACE_API_KEY = os.environ.get("HUGGINGFACE_API_KEY")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

# Hugging Face API configuration - using Flan-T5 for reliable text generation
HF_API_URL = "https://api-inference.huggingface.co/models/google/flan-t5-base"
HF_HEADERS = {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"}

def get_huggingface_response(user_message):
    """
    Get AI response from Hugging Face API
    
    Args:
        user_message (str): The user's input message
        
    Returns:
        str: AI response message
    """
    try:
        # Prepare the payload for Hugging Face Flan-T5 API
        prompt = f"Answer this question as Deena's Assistant AI, a helpful and friendly AI assistant: {user_message}"
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_length": 100,
                "temperature": 0.7,
                "do_sample": True
            }
        }
        
        response = requests.post(HF_API_URL, headers=HF_HEADERS, json=payload)
        
        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                generated_text = result[0].get('generated_text', '').strip()
                # Clean up the response
                if generated_text:
                    return generated_text
                else:
                    return "I'm here to help! Could you please rephrase your question?"
            else:
                return "I'm processing your message. Could you try asking in a different way?"
        else:
            logging.error(f"Hugging Face API error: {response.status_code} - {response.text}")
            return "I'm having trouble connecting to my AI service. Please try again in a moment."
            
    except Exception as e:
        logging.error(f"Error getting Hugging Face response: {str(e)}")
        return "I'm experiencing some technical difficulties. Please try again shortly."


def get_simple_ai_response(user_message):
    """
    Generate a contextual AI response based on user input patterns
    
    Args:
        user_message (str): The user's input message
        
    Returns:
        str: AI response message
    """
    import random
    
    message_lower = user_message.lower()
    
    # Greetings
    if any(word in message_lower for word in ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening']):
        greetings = [
            "Hello! I'm Deena's Assistant AI. How can I help you today?",
            "Hi there! What can I assist you with?",
            "Hey! Great to meet you. What would you like to know?",
            "Hello! I'm here to help with any questions you have."
        ]
        return random.choice(greetings)
    
    # Questions about the assistant
    elif any(phrase in message_lower for phrase in ['who are you', 'what are you', 'about yourself', 'introduce']):
        return "I'm Deena's Assistant AI, a helpful assistant created to answer questions and provide information. I can help with various topics - what interests you?"
    
    # Weather questions
    elif any(word in message_lower for word in ['weather', 'temperature', 'rain', 'sunny', 'cloudy']):
        return "I don't have access to current weather data, but I'd recommend checking a weather app or website for accurate, up-to-date information about your local conditions!"
    
    # Time questions
    elif any(word in message_lower for word in ['time', 'date', 'today', 'clock']):
        return "I don't have access to real-time information, but you can check the time and date on your device. Is there something specific about time management I can help you with?"
    
    # Math questions
    elif any(word in message_lower for word in ['calculate', 'math', 'plus', 'minus', 'multiply', 'divide', '+', '-', '*', '/']):
        return "I can help with basic math concepts! For complex calculations, I'd recommend using a calculator app. What kind of math problem are you working on?"
    
    # Technology questions
    elif any(word in message_lower for word in ['computer', 'software', 'app', 'website', 'internet', 'tech']):
        return "Technology questions are interesting! While I can discuss general tech concepts, for specific troubleshooting I'd recommend checking official documentation or support resources. What tech topic interests you?"
    
    # Cooking/food questions
    elif any(word in message_lower for word in ['cook', 'recipe', 'food', 'eat', 'meal', 'kitchen']):
        return "Cooking is wonderful! While I can't provide specific recipes, I'd suggest checking cooking websites or apps for detailed instructions. What type of cuisine or cooking technique interests you?"
    
    # Learning/education questions
    elif any(word in message_lower for word in ['learn', 'study', 'school', 'education', 'teach', 'explain']):
        return "Learning is fantastic! I can discuss general concepts, but for detailed educational content, I'd recommend textbooks, educational websites, or speaking with teachers. What subject are you curious about?"
    
    # Help requests
    elif any(word in message_lower for word in ['help', 'assist', 'support', 'need']):
        return "I'm here to help! I can discuss various topics and provide general guidance. What specific area would you like assistance with?"
    
    # Thanks/appreciation
    elif any(word in message_lower for word in ['thank', 'thanks', 'appreciate', 'grateful']):
        responses = [
            "You're very welcome! Happy to help anytime.",
            "My pleasure! Is there anything else I can assist with?",
            "Glad I could help! Feel free to ask more questions.",
            "You're welcome! That's what I'm here for."
        ]
        return random.choice(responses)
    
    # Goodbye
    elif any(word in message_lower for word in ['bye', 'goodbye', 'see you', 'farewell', 'later']):
        goodbyes = [
            "Goodbye! Feel free to come back anytime with questions.",
            "See you later! Have a great day!",
            "Farewell! It was nice chatting with you.",
            "Take care! I'm here whenever you need assistance."
        ]
        return random.choice(goodbyes)
    
    # General questions (contains question mark)
    elif '?' in user_message:
        question_responses = [
            f"That's an interesting question! While I'm operating in a simplified mode, I can tell you're asking about '{user_message.replace('?', '')}'. For detailed information, I'd recommend researching this topic further. What specifically interests you about this?",
            f"Great question! You're asking about something important. While I can discuss general concepts, for specific details about '{user_message.replace('?', '')}', I'd suggest consulting specialized resources. What aspect would you like to explore?",
            f"I can see you're curious about '{user_message.replace('?', '')}'. That's a topic worth exploring! For comprehensive information, I'd recommend checking authoritative sources. Is there a particular angle you're most interested in?"
        ]
        return random.choice(question_responses)
    
    # Default contextual responses
    else:
        contextual_responses = [
            f"I see you mentioned '{user_message}'. That's interesting! While I'm in a simplified response mode, I can engage in general discussion about various topics. What would you like to explore further?",
            f"Thanks for sharing that: '{user_message}'. I'm here to chat and provide general guidance on different subjects. What questions do you have?",
            f"I understand you're talking about '{user_message}'. I can discuss various topics in general terms. What specific aspect interests you most?",
            f"That's an interesting point about '{user_message}'. I'm happy to continue our conversation! What would you like to discuss next?"
        ]
        return random.choice(contextual_responses)


def get_ai_response(user_message):
    """
    Get AI response using available services with intelligent fallback
    
    Args:
        user_message (str): The user's input message
        
    Returns:
        str: AI response message
    """
    # Try Gemini first if API key is available (highest priority)
    if GEMINI_API_KEY:
        logging.debug("Using Gemini AI for response")
        try:
            gemini_response = get_gemini_response(user_message)
            # If we get a proper response (not an error message), use it
            if not any(phrase in gemini_response.lower() for phrase in ['trouble generating', 'technical difficulties', 'try again']):
                return gemini_response
        except Exception as e:
            logging.error(f"Gemini failed: {e}")
    
    # Try Hugging Face as backup
    if HUGGINGFACE_API_KEY:
        logging.debug("Attempting Hugging Face API for response")
        try:
            hf_response = get_huggingface_response(user_message)
            # If we get a proper response (not an error message), use it
            if not any(phrase in hf_response.lower() for phrase in ['trouble connecting', 'technical difficulties', 'try again']):
                return hf_response
        except Exception as e:
            logging.error(f"Hugging Face failed: {e}")
    
    # Try OpenAI if available and others failed
    if OPENAI_API_KEY:
        logging.debug("Attempting OpenAI API for response")
        try:
            openai_response = get_openai_response(user_message)
            # If we get a proper response (not an error message), use it
            if not any(phrase in openai_response.lower() for phrase in ['quota', 'billing', 'technical difficulties']):
                return openai_response
        except Exception as e:
            logging.error(f"OpenAI failed: {e}")
    
    # Use simple AI as fallback
    logging.debug("Using simple AI fallback response")
    return get_simple_ai_response(user_message)


def get_openai_response(user_message):
    """
    Get AI response from OpenAI API (fallback option)
    
    Args:
        user_message (str): The user's input message
        
    Returns:
        str: AI response message
    """
    try:
        from openai import OpenAI
        openai_client = OpenAI(api_key=OPENAI_API_KEY)
        
        system_prompt = """You are Deena's Assistant AI, a helpful and friendly AI assistant. 
        You should be conversational, knowledgeable, and supportive. 
        Provide clear, helpful responses while maintaining a warm and professional tone.
        Keep responses concise but informative."""
        
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logging.error(f"Error getting OpenAI response: {str(e)}")
        if "quota" in str(e).lower() or "insufficient_quota" in str(e).lower():
            return "Hi! I'm Deena's Assistant AI. The OpenAI API key has exceeded its quota limit. Please check the billing at https://platform.openai.com/account/billing to add credits."
        else:
            return "I'm experiencing some technical difficulties right now. Please try again in a moment."
