import logging
import uuid
from datetime import datetime
from flask import render_template, request, jsonify, session
from app import app, db
from models import ChatSession, ChatMessage
from ai_service import get_ai_response

@app.route("/")
def index():
    """Serve the main chat interface"""
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    """Handle chat messages and return AI responses"""
    try:
        # Get the message from the request
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "No message provided"}), 400
        
        user_message = data["message"].strip()
        if not user_message:
            return jsonify({"error": "Empty message"}), 400
        
        logging.debug(f"Received message: {user_message}")
        
        # Get or create session
        session_id = get_or_create_session()
        
        # Save user message to database
        user_msg = ChatMessage(
            session_id=session_id,
            message_type='user',
            content=user_message
        )
        db.session.add(user_msg)
        
        # Get AI response
        ai_response = get_ai_response(user_message)
        
        # Save AI response to database
        bot_msg = ChatMessage(
            session_id=session_id,
            message_type='bot',
            content=ai_response
        )
        db.session.add(bot_msg)
        
        # Update session activity
        chat_session = ChatSession.query.filter_by(session_id=session_id).first()
        if chat_session:
            chat_session.last_activity = datetime.utcnow()
        
        db.session.commit()
        
        logging.debug(f"AI response: {ai_response}")
        
        return jsonify({"reply": ai_response})
    
    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        db.session.rollback()
        return jsonify({
            "reply": "I'm sorry, I'm having trouble processing your request right now. Please try again later."
        }), 500


def get_or_create_session():
    """Get existing session ID or create a new one"""
    if 'session_id' not in session:
        # Create new session
        session_id = str(uuid.uuid4())
        session['session_id'] = session_id
        
        # Create database record
        chat_session = ChatSession(session_id=session_id)
        db.session.add(chat_session)
        db.session.commit()
        
        logging.debug(f"Created new chat session: {session_id}")
    
    return session['session_id']


@app.route("/history")
def chat_history():
    """Get chat history for current session"""
    try:
        session_id = session.get('session_id')
        if not session_id:
            return jsonify({"messages": []})
        
        messages = ChatMessage.query.filter_by(session_id=session_id)\
                                  .order_by(ChatMessage.timestamp.asc())\
                                  .all()
        
        return jsonify({
            "messages": [msg.to_dict() for msg in messages]
        })
    
    except Exception as e:
        logging.error(f"Error retrieving chat history: {str(e)}")
        return jsonify({"error": "Failed to retrieve chat history"}), 500


@app.route("/sessions")
def all_sessions():
    """Get all chat sessions (for admin purposes)"""
    try:
        sessions = ChatSession.query.order_by(ChatSession.last_activity.desc()).all()
        
        session_data = []
        for chat_session in sessions:
            message_count = len(chat_session.messages)
            session_data.append({
                'session_id': chat_session.session_id,
                'created_at': chat_session.created_at.isoformat(),
                'last_activity': chat_session.last_activity.isoformat(),
                'message_count': message_count
            })
        
        return jsonify({"sessions": session_data})
    
    except Exception as e:
        logging.error(f"Error retrieving sessions: {str(e)}")
        return jsonify({"error": "Failed to retrieve sessions"}), 500


@app.route("/clear_session", methods=["POST"])
def clear_session():
    """Clear current chat session"""
    try:
        session_id = session.get('session_id')
        if session_id:
            # Remove session from Flask session
            session.pop('session_id', None)
        
        return jsonify({"message": "Session cleared successfully"})
    
    except Exception as e:
        logging.error(f"Error clearing session: {str(e)}")
        return jsonify({"error": "Failed to clear session"}), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({"error": "Internal server error"}), 500
